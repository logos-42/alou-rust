#!/bin/bash
echo "🔧 Alou Desktop安装脚本"
echo "========================"

# 检查系统
if [[ "$(uname)" != "Linux" ]]; then
    echo "⚠️  警告: 此脚本主要针对Linux系统"
fi

echo ""
echo "1. 安装Node.js (如果需要)..."
if ! command -v node &> /dev/null; then
    echo "❌ Node.js未安装"
    echo "   请访问 https://nodejs.org/ 安装Node.js 18+"
    echo "   或使用包管理器:"
    echo "   Ubuntu/Debian: sudo apt install nodejs npm"
    echo "   CentOS/RHEL: sudo yum install nodejs npm"
    echo "   Fedora: sudo dnf install nodejs npm"
    exit 1
else
    echo "✅ Node.js已安装: $(node --version)"
fi

echo ""
echo "2. 复制文件..."
INSTALL_DIR="${HOME}/.local/share/alou-desktop"
mkdir -p "${INSTALL_DIR}"
cp -r . "${INSTALL_DIR}/"
chmod +x "${INSTALL_DIR}/start.sh"

echo ""
echo "3. 创建桌面快捷方式..."
DESKTOP_FILE="${HOME}/.local/share/applications/alou-desktop.desktop"
cat > "${DESKTOP_FILE}" << DESKTOP
[Desktop Entry]
Name=Alou Desktop
Comment=Web3 AI Agent Desktop Application
Exec=${INSTALL_DIR}/start.sh
Icon=${INSTALL_DIR}/web/favicon.ico
Terminal=true
Type=Application
Categories=Development;Network;
StartupNotify=true
DESKTOP

chmod +x "${DESKTOP_FILE}"

echo ""
echo "✅ 安装完成!"
echo ""
echo "🎯 启动方式:"
echo "   1. 在应用菜单中搜索 'Alou Desktop'"
echo "   2. 或运行: ${INSTALL_DIR}/start.sh"
echo ""
echo "📖 文档: ${INSTALL_DIR}/README.md"
echo ""
echo "⚠️  注意: 这是一个Web应用，需要在浏览器中访问 http://localhost:3000"
