#!/bin/bash
# Alou Desktop安装脚本

echo "🔧 安装 Alou Desktop..."

# 检查系统
if [[ "$(uname)" != "Linux" ]]; then
    echo "❌ 错误: 此安装包仅适用于Linux系统"
    exit 1
fi

# 创建应用目录
INSTALL_DIR="${HOME}/.local/share/alou-desktop"
mkdir -p "${INSTALL_DIR}"

echo "📁 复制文件到 ${INSTALL_DIR}..."
cp -r . "${INSTALL_DIR}/"

# 创建桌面快捷方式
cat > "${HOME}/.local/share/applications/alou.desktop" << DESKTOP
[Desktop Entry]
Name=Alou Desktop
Comment=Web3 AI Agent Desktop Application
Exec=${INSTALL_DIR}/start.sh
Icon=${INSTALL_DIR}/public/favicon.ico
Terminal=false
Type=Application
Categories=Development;Utility;
StartupNotify=true
DESKTOP

chmod +x "${HOME}/.local/share/applications/alou.desktop"

echo "✅ 安装完成!"
echo ""
echo "🎯 启动方式:"
echo "1. 在应用菜单中搜索 'Alou'"
echo "2. 或运行: ${INSTALL_DIR}/start.sh"
echo ""
echo "📖 文档: ${INSTALL_DIR}/README.md"
