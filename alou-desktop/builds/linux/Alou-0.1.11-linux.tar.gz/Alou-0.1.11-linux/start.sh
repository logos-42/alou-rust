#!/bin/bash
# Alou Desktop启动脚本

echo "🚀 启动 Alou Desktop..."

# 检查Node.js
if ! command -v node &> /dev/null; then
    echo "❌ 错误: Node.js未安装"
    echo "请先安装Node.js: https://nodejs.org/"
    exit 1
fi

if ! command -v npm &> /dev/null; then
    echo "❌ 错误: npm未安装"
    exit 1
fi

# 安装依赖
echo "📦 安装依赖..."
npm install

# 启动开发服务器
echo "🌐 启动开发服务器..."
npm run dev

echo "✅ Alou Desktop已启动!"
echo "🌐 请在浏览器中访问: http://localhost:1420"
