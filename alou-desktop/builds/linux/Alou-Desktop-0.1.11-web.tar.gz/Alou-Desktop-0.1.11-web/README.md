# Alou Desktop - Web3 AI Agent桌面应用

## 概述
Alou Desktop是一个基于Web3和AI技术的智能体桌面应用，支持去中心化群聊和多智能体协作。

## 系统要求
- **操作系统**: Linux (Ubuntu/Debian/CentOS/Fedora等)
- **Node.js**: 18.0.0 或更高版本
- **内存**: 至少 2GB RAM
- **磁盘空间**: 至少 500MB 可用空间

## 快速开始

### 方法1: 直接运行
```bash
# 解压
tar -xzf Alou-Desktop-0.1.11-web.tar.gz
cd Alou-Desktop-0.1.11-web

# 启动
./start.sh
```

### 方法2: 安装到系统
```bash
tar -xzf Alou-Desktop-0.1.11-web.tar.gz
cd Alou-Desktop-0.1.11-web
./install.sh
```

## 访问应用
启动服务器后，在浏览器中访问: **http://localhost:3000**

## 功能特性

### 🚀 核心功能
- **去中心化群聊**: 基于IPFS PubSub的实时消息传递
- **多智能体协作**: 多个AI Agent协同完成任务
- **Web3集成**: 支持以太坊和Solana钱包认证
- **AI智能体**: 集成DeepSeek/Claude等AI对话系统

### 🔧 技术栈
- **前端**: React + TypeScript + Vite
- **后端**: Node.js HTTP服务器
- **通信**: WebSocket + REST API
- **存储**: 本地文件系统 + 内存存储

## 配置文件
配置文件位于 `config/` 目录:
- `config/default.json` - 默认配置
- `config/production.json` - 生产环境配置

## 开发模式
如需开发模式，请从源代码构建:

```bash
# 克隆项目
git clone https://github.com/logos-42/alou-rust.git
cd alou-rust/alou-desktop

# 安装依赖
npm install

# 开发模式
npm run dev
# 访问 http://localhost:1420
```

## 故障排除

### 1. 端口占用
如果端口3000被占用，可以修改 `start-server.js` 中的 `PORT` 变量。

### 2. Node.js版本问题
```bash
# 使用nvm管理Node.js版本
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
nvm install 18
nvm use 18
```

### 3. 权限问题
```bash
# 给脚本执行权限
chmod +x start.sh install.sh
```

### 4. 浏览器访问问题
- 确保防火墙允许端口3000
- 检查服务器是否正常运行
- 查看控制台输出是否有错误

## 更新日志
- **v0.1.11**: Web部署版本，包含完整前端功能
- **v0.1.10**: 初始版本，基础AI Agent功能

## 技术支持
- GitHub: https://github.com/logos-42/alou-rust
- 问题反馈: 创建GitHub Issue

## 许可证
MIT License - 详见LICENSE文件
