/**
 * 旧版翻译 key（向后兼容）
 *
 * 这些是旧代码中使用的扁平化 key，保留以确保向后兼容。
 * 新代码应使用命名空间格式的 key（如 agent.create.title）
 *
 * TODO: 逐步迁移旧代码后删除此文件
 */
export const legacy = {
  zh: {
    // 应用基础
    appTitle: 'Alou智能助手',
    connected: '已连接',
    disconnected: '连接失败',
    connecting: '连接中...',
    login: '登录',
    logout: '退出登录',

    // 设置
    walletManagement: '钱包管理',
    settings: '设置',
    language: '语言',
    theme: '主题',
    darkMode: '深色模式',
    lightMode: '浅色模式',

    // 对话
    welcome: '欢迎使用Alou智能助手',
    welcomeDesc: '我是区块链支付的AI助手，很高兴为您提供智能服务。',
    inputPlaceholder: '输入您的问题...（Enter发送，Shift+Enter换行）',
    send: '发送',
    thinking: 'AI正在思考中...',
    queryBalance: '查询钱包余额',
    sendTokens: '发送代币',
    transactionHistory: '交易历史',
    error: '抱歉，发生了错误',
    networkError: '请检查网络连接或稍后重试',

    // 钱包相关
    back: '返回',
    connectWallet: '连接钱包',
    connectWalletDesc: '连接你的钱包以开始使用',
    disconnect: '断开连接',
    switchWallet: '切换钱包',
    balance: '余额',
    networkSettings: '网络设置',
    recentTransactions: '最近交易',
    noTransactions: '暂无交易记录',
    sent: '发送',
    received: '接收',

    // 合约钱包
    agentContractWallet: '智能体合约钱包',
    createContractWallet: '创建合约钱包',
    noContractWallet: '还没有合约钱包',
    contractWalletHint: '创建一个智能合约钱包，让AI助手帮你管理资金',
    agentWallet: '智能体钱包',
    totalBalance: '总余额',
    deposit: '存入',
    withdraw: '提取',
    manage: '管理',

    // 签名
    signatureRequest: '签名请求',
    from: '从',
    to: '到',
    amount: '金额',
    gasFee: 'Gas费用',
    signatureWarning: '请仔细检查交易详情，确认后将无法撤销',
    cancel: '取消',
    confirm: '确认',
    signing: '签名中',

    // 状态
    installMetaMask: '请先安装 MetaMask',
    connectionFailed: '连接失败',
    walletConnectComingSoon: 'WalletConnect 即将推出',
    contractWalletCreated: '合约钱包创建成功',
    createFailed: '创建失败',
    enterDepositAmount: '请输入存入金额（ETH）',
    enterWithdrawAmount: '请输入提取金额（ETH）',
    contractManagementComingSoon: '合约管理功能即将推出',
    transactionSent: '交易已发送',
    transactionFailed: '交易失败',

    // 时间
    justNow: '刚刚',
    minutesAgo: '分钟前',
    hoursAgo: '小时前',
    daysAgo: '天前',

    // 其他
    agentAssets: '智能体资产',
    refresh: '刷新',
    noWalletConnected: '尚未连接钱包',
    currentNetwork: '当前网络',
    interactionLogs: '互动记录',
    expand: '展开',
    collapse: '收起',
  },
  en: {
    // App basics
    appTitle: 'Alou AI Assistant',
    connected: 'Connected',
    disconnected: 'Disconnected',
    connecting: 'Connecting...',
    login: 'Login',
    logout: 'Logout',

    // Settings
    walletManagement: 'Wallet',
    settings: 'Settings',
    language: 'Language',
    theme: 'Theme',
    darkMode: 'Dark Mode',
    lightMode: 'Light Mode',

    // Chat
    welcome: 'Welcome to Alou AI Assistant',
    welcomeDesc: 'I am your blockchain payment AI assistant, happy to help you.',
    inputPlaceholder: 'Type your question... (Enter to send, Shift+Enter for new line)',
    send: 'Send',
    thinking: 'AI is thinking...',
    queryBalance: 'Query Balance',
    sendTokens: 'Send Tokens',
    transactionHistory: 'Transaction History',
    error: 'Sorry, an error occurred',
    networkError: 'Please check your network connection or try again later',

    // Wallet related
    back: 'Back',
    connectWallet: 'Connect Wallet',
    connectWalletDesc: 'Connect your wallet to get started',
    disconnect: 'Disconnect',
    switchWallet: 'Switch Wallet',
    balance: 'Balance',
    networkSettings: 'Network Settings',
    recentTransactions: 'Recent Transactions',
    noTransactions: 'No transactions yet',
    sent: 'Sent',
    received: 'Received',

    // Contract wallet
    agentContractWallet: 'Agent Contract Wallet',
    createContractWallet: 'Create Contract Wallet',
    noContractWallet: 'No contract wallet yet',
    contractWalletHint: 'Create a smart contract wallet for AI agent to manage funds',
    agentWallet: 'Agent Wallet',
    totalBalance: 'Total Balance',
    deposit: 'Deposit',
    withdraw: 'Withdraw',
    manage: 'Manage',

    // Signature
    signatureRequest: 'Signature Request',
    from: 'From',
    to: 'To',
    amount: 'Amount',
    gasFee: 'Gas Fee',
    signatureWarning: 'Please review transaction details carefully, this cannot be undone',
    cancel: 'Cancel',
    confirm: 'Confirm',
    signing: 'Signing',

    // Status
    installMetaMask: 'Please install MetaMask first',
    connectionFailed: 'Connection failed',
    walletConnectComingSoon: 'WalletConnect coming soon',
    contractWalletCreated: 'Contract wallet created successfully',
    createFailed: 'Creation failed',
    enterDepositAmount: 'Enter deposit amount (ETH)',
    enterWithdrawAmount: 'Enter withdraw amount (ETH)',
    contractManagementComingSoon: 'Contract management coming soon',
    transactionSent: 'Transaction sent',
    transactionFailed: 'Transaction failed',

    // Time
    justNow: 'Just now',
    minutesAgo: ' minutes ago',
    hoursAgo: ' hours ago',
    daysAgo: ' days ago',

    // Others
    agentAssets: 'Agent Assets',
    refresh: 'Refresh',
    noWalletConnected: 'No wallet connected',
    currentNetwork: 'Current network',
    interactionLogs: 'Interaction Logs',
    expand: 'Expand',
    collapse: 'Collapse',
  },
}
