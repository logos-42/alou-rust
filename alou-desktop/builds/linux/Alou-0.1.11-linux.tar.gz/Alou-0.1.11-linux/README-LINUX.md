# Alou Desktop Linux版本

## 系统要求
- Linux (Ubuntu/Debian/CentOS/Fedora等)
- Node.js 18+
- npm 10+

## 快速开始

### 方法1: 直接运行
```bash
chmod +x start.sh
./start.sh
```

### 方法2: 安装到系统
```bash
chmod +x install.sh
./install.sh
```

## 构建说明

此包包含Alou Desktop的完整源代码，需要以下工具进行构建：

### 开发环境
```bash
# 安装Node.js依赖
npm install

# 启动开发服务器
npm run dev
```

### 生产构建 (需要Rust和Tauri CLI)
```bash
# 安装Tauri CLI
npm install @tauri-apps/cli

# 构建Linux AppImage
npm run build:tauri:linux
```

## 项目结构
- `src/` - 前端源代码 (React + TypeScript)
- `src-tauri/` - Rust后端代码
- `public/` - 静态资源
- `config/` - 配置文件
- `docs/` - 文档

## 故障排除

### 1. Node.js版本问题
```bash
# 使用nvm管理Node.js版本
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
nvm install 18
nvm use 18
```

### 2. 端口占用
默认端口1420被占用时，可以修改`vite.config.js`中的端口配置。

### 3. 依赖安装失败
```bash
# 清理npm缓存
npm cache clean --force
rm -rf node_modules package-lock.json
npm install
```

## 技术支持
- GitHub: https://github.com/logos-42/alou-rust
- 文档: 查看docs/目录

## 许可证
MIT License - 详见LICENSE文件
