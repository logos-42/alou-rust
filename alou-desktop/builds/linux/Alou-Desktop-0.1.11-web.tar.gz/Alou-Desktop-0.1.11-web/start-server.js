const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = 3000;
const WEB_DIR = path.join(__dirname, 'web');

const MIME_TYPES = {
  '.html': 'text/html',
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain',
  '.pdf': 'application/pdf',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.eot': 'application/vnd.ms-fontobject',
  '.otf': 'font/otf'
};

const server = http.createServer((req, res) => {
  console.log(`${new Date().toISOString()} ${req.method} ${req.url}`);
  
  const parsedUrl = url.parse(req.url);
  let pathname = path.join(WEB_DIR, parsedUrl.pathname);
  
  // 默认加载index.html
  if (parsedUrl.pathname === '/') {
    pathname = path.join(WEB_DIR, 'index.html');
  }
  
  // 检查文件是否存在
  fs.stat(pathname, (err, stats) => {
    if (err) {
      // 文件不存在，返回index.html用于SPA路由
      if (req.method === 'GET' && !pathname.includes('.')) {
        const fallbackPath = path.join(WEB_DIR, 'index.html');
        fs.readFile(fallbackPath, (err, data) => {
          if (err) {
            res.statusCode = 404;
            res.end(`File ${fallbackPath} not found!`);
          } else {
            res.setHeader('Content-Type', 'text/html');
            res.end(data);
          }
        });
      } else {
        res.statusCode = 404;
        res.end(`File ${pathname} not found!`);
      }
      return;
    }
    
    if (stats.isDirectory()) {
      pathname = path.join(pathname, 'index.html');
    }
    
    // 读取文件
    fs.readFile(pathname, (err, data) => {
      if (err) {
        res.statusCode = 500;
        res.end(`Error getting the file: ${err}.`);
      } else {
        const ext = path.parse(pathname).ext;
        res.setHeader('Content-Type', MIME_TYPES[ext] || 'application/octet-stream');
        res.end(data);
      }
    });
  });
});

server.listen(PORT, () => {
  console.log(`🚀 Alou Desktop服务器已启动!`);
  console.log(`🌐 访问地址: http://localhost:${PORT}`);
  console.log(`📁 静态文件目录: ${WEB_DIR}`);
  console.log(`🔄 按 Ctrl+C 停止服务器`);
});

// 优雅关闭
process.on('SIGINT', () => {
  console.log('\n👋 正在关闭服务器...');
  server.close(() => {
    console.log('✅ 服务器已关闭');
    process.exit(0);
  });
});
