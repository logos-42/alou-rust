#!/bin/bash
echo "🚀 启动 Alou Desktop Web服务器..."
echo "📦 版本: 0.1.11"
echo ""

# 检查Node.js
if ! command -v node &> /dev/null; then
    echo "❌ 错误: Node.js未安装"
    echo "请先安装Node.js: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js版本: $(node --version)"
echo "🌐 启动服务器..."

node start-server.js
